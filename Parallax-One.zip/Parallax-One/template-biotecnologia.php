<?php
/**
 * Template name: biotecnologia
 *
 * 
 */

?>



<html lang="es-ES" class="no-js">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="profile" href="http://gmpg.org/xfn/11">
      <link rel="pingback" href="http://programas.colmayor.edu.co/xmlrpc.php">
      <title>Biotecnologia - Colmayor</title>
      <link rel="dns-prefetch" href="//fonts.googleapis.com">
      <link rel="dns-prefetch" href="//s.w.org">
      <link rel="alternate" type="application/rss+xml" title="Programas Colmayor » Feed" href="http://programas.colmayor.edu.co/feed/">
      <link rel="alternate" type="application/rss+xml" title="Programas Colmayor » RSS de los comentarios" href="http://programas.colmayor.edu.co/comments/feed/">
      <script id="twitter-wjs" src="https://platform.twitter.com/widgets.js"></script><script async="" src="//www.googletagmanager.com/gtm.js?id=GTM-WGDWZNL"></script><script type="text/javascript">
         window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"\/\/programas.colmayor.edu.co\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.8.3"}};
         !function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,56826,8203,55356,56819),0,0),c=j.toDataURL(),b!==c&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55358,56794,8205,9794,65039),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55358,56794,8203,9794,65039),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
      </script><script src="//programas.colmayor.edu.co/wp-includes/js/wp-emoji-release.min.js?ver=4.8.3" type="text/javascript" defer=""></script>
      <style type="text/css">
         img.wp-smiley,
         img.emoji {
         display: inline !important;
         border: none !important;
         box-shadow: none !important;
         height: 1em !important;
         width: 1em !important;
         margin: 0 .07em !important;
         vertical-align: -0.1em !important;
         background: none !important;
         padding: 0 !important;
         }
      </style>
      <link rel="stylesheet" id="parallax-one-fonts-css" href="//fonts.googleapis.com/css?family=Cabin%3A400%2C600%7COpen+Sans%3A400%2C300%2C600&amp;subset=latin%2Clatin-ext" type="text/css" media="all">
      <link rel="stylesheet" id="parallax-one-bootstrap-style-css" href="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/css/bootstrap.min.css?ver=3.3.1" type="text/css" media="all">
      <link rel="stylesheet" id="parallax-one-font-awesome-css" href="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/css/font-awesome.min.css?ver=4.8.3" type="text/css" media="all">
      <link rel="stylesheet" id="parallax-one-style-css" href="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/style.css?ver=1.0.0" type="text/css" media="all">
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-includes/js/jquery/jquery.js?ver=1.12.4"></script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-form-move-tracker.js?ver=1.7.1"></script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-social-tracker.js?ver=1.7.1"></script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-content/plugins/duracelltomi-google-tag-manager/js/analytics-talk-content-tracking.js?ver=1.7.1"></script>
      <link rel="https://api.w.org/" href="http://programas.colmayor.edu.co/wp-json/">
      <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://programas.colmayor.edu.co/xmlrpc.php?rsd">
      <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://programas.colmayor.edu.co/wp-includes/wlwmanifest.xml">
      <meta name="generator" content="WordPress 4.8.3">
      <!-- Google Tag Manager for WordPress by DuracellTomi - http://duracelltomi.com -->
      <script data-cfasync="false" type="text/javascript">
         var gtm4wp_datalayer_name = "dataLayer";
         var dataLayer = dataLayer || [];
         
         var gtm4wp_scrollerscript_debugmode         = false;
         var gtm4wp_scrollerscript_callbacktime      = 100;
         var gtm4wp_scrollerscript_readerlocation    = 150;
         var gtm4wp_scrollerscript_contentelementid  = "content";
         var gtm4wp_scrollerscript_scannertime       = 60;
         var google_tag_params = {"siteID":0,"siteName":"","pagePostType":"frontpage"};
         dataLayer.push({"siteID":0,"siteName":"","visitorLoginState":"logged-out","visitorEmail":"","pagePostType":"frontpage","google_tag_params":window.google_tag_params});
      </script>
      <script data-cfasync="false">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
         new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
         j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
         '//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
         })(window,document,'script','dataLayer','GTM-WGDWZNL');
      </script>
      <!-- End Google Tag Manager -->
      <!-- End Google Tag Manager for WordPress by DuracellTomi --><!--[if lt IE 9]>
      <script src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/js/html5shiv.min.js"></script>
      <![endif]-->
      <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>


      <style type="text/css">
      	body{ line-height: 1.3; }
      	.brief p {
			margin-top: 0px; 
		}
		.brief-content-text {
		    margin-top: 0px;
		}
		.brief .brief-image-right {
		    margin-top: 0px;
		}
		.brief .content-section {
		    margin-top: 0px; 
		}
		.header {
    		background-image: url(//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/imagen_home_colmayor.jpg) !important;
		}
		.overlay-layer-wrap {
		    background: rgba(0, 0, 0, 0);
		}
		.parallax_one_grid_col_2 {
		    width: 45% !important;;
		}

		.single-service {
		    padding: 0;
		    border: none;
		    border-radius: 0;
		    background: none;
		    -webkit-transition: all ease 0.55s;
		    transition: all ease 0.55s;
		}
		.razones-numeros {
			display: inline-flex;
			background-color: rgba(255,255,255,0.5);
			font-weight: bold;    
			font-size: 16px; 
			padding: 15px 20px;
		    margin-top: 10px;
	        width: 100%;
		}

		.razones-numeros h3{
			font-size: 80px;
		    margin: 10px 0;
			color: #0E8080;
		}

		.razones-numeros p{
			width: 100%;
			margin: 0;
		}
		.service-icon img {
		    width: 100px;
		}

		.call-to-action .section-overlay-layer {
		    background: rgba(0, 5, 8, 0);
		}

		.brief-content-text li {
		    margin-top: 20px;
		}

      .menu-align-center .navbar-header, .menu-align-center .navbar-collapse {
          width: auto;
      }

      	.razon-para-estudiar{
      		margin-top: 25px;
      	}

		</style>
   </head>
   <body itemscope="" itemtype="http://schema.org/WebPage" class="home blog" dir="ltr">
      <div id="mobilebgfix">
         <div class="mobile-bg-fix-img-wrap">
            <div class="mobile-bg-fix-img"></div>
         </div>
         <div class="mobile-bg-fix-whole-site">
            <a class="skip-link screen-reader-text" href="#content">Skip to content</a>
            <div class="preloader" style="display: none;">
               <div class="status" style="display: none;">&nbsp;</div>
            </div>
            <header itemscope="" itemtype="http://schema.org/WPHeader" id="masthead" role="banner" data-stellar-background-ratio="0.5" class="header header-style-one site-header" style="opacity: 1;">
               <!-- COLOR OVER IMAGE -->
               <div class="overlay-layer-nav sticky-navigation-open" style="min-height: 70px;">
                  <!-- STICKY NAVIGATION -->
                  <div class="navbar navbar-inverse bs-docs-nav navbar-fixed-top sticky-navigation appear-on-scroll" style="        background: rgba(4, 4, 4, 0.7);color: white;">
                     <!-- CONTAINER -->
                     <div class="container">
                        <div class="navbar-header">
                           <!-- LOGO -->
                           <button title="Toggle Menu" type="button" class="navbar-toggle menu-toggle" id="menu-toggle" data-toggle="collapse" data-target="#menu-primary">
                           <span class="screen-reader-text">Toggle navigation</span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           </button>
                           <a href="#inicio" class="navbar-brand" title="Programas Colmayor">
                           	<img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/logo-landing.png" alt="Programas Colmayor">
                       	   </a>
                           <div class="header-logo-wrap text-header paralax_one_only_customizer">
                              <h1 itemprop="headline" id="site-title" class="site-title"><a href="http://programas.colmayor.edu.co/" title="Programas Colmayor" rel="home">Programas Colmayor</a></h1>
                              <p itemprop="description" id="site-description" class="site-description">Biotecnologia</p>
                           </div>
                        </div>
                        <!-- MENU -->
                        <div itemscope="" itemtype="http://schema.org/SiteNavigationElement" aria-label="Primary Menu" id="menu-primary" class="navbar-collapse collapse">
                           <!-- LOGO ON STICKY NAV BAR -->
                           <div id="site-header-menu" class="site-header-menu">
                              <nav id="site-navigation" class="main-navigation" role="navigation">
                                 <ul class="nav navbar-nav navbar-right main-navigation small-text no-menu">
                                    <li class="page_item page-item-30">
                                    	<a href="#informacion-programa">Información del programa</a>
                                	</li>
                                    <li class="page_item page-item-9">
                                    	<a href="#five-razones">5 razones para estudiar en Colmayor</a>
                                	</li>
                                    <li class="page_item page-item-2">
                                    	<a href="#testimonios">Testimonios</a>
                                	</li>
                                    <li class="page_item page-item-2">
                                    	<a href="#creditos-educativos">Créditos educativos y becas</a>
                                	</li>
                                 </ul>
                              </nav>
                           </div>
                        </div>
                     </div>
                     <!-- /END CONTAINER -->
                  </div>
                  <!-- /END STICKY NAVIGATION -->
                  <div class="overlay-layer-wrap" id="inicio">
                     <div class="container overlay-layer" id="parallax_header" style="padding-top: 154px;">
                        <!-- ONLY LOGO ON HEADER -->
                        <div class="only-logo">
                           <div id="only-logo-inner" class="navbar">
                              <div id="parallax_only_logo" class="navbar-header"><img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/Texto_home.png" alt="Programas Colmayor"></div>
                           </div>
                        </div>
                        <!-- /END ONLY LOGO ON HEADER -->
                        <div class="row">
                           <div class="col-md-12 intro-section-text-wrap">
                              <!-- HEADING AND BUTTONS -->
                              <div id="intro-section" class="intro-section">
                                                                
                              </div>
                              <!-- /END HEADNING AND BUTTONS -->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- /END COLOR OVER IMAGE -->
            </header>
            <!-- /END HOME / HEADER  -->
            <div itemprop="" id="content" class="content-warp" role="main">
               
              <section class="brief text-left brief-design-one brief-left" id="informacion-programa" role="region" aria-label="About">
                  <div class="section-overlay-layer">
                     <div class="container">
                        <div class="row">
                           <!-- BRIEF IMAGE -->
                           <div class="col-xs-10 col-xs-offset-1  col-md-offset-0  col-md-6 brief-content-one">
                              <div class="brief-image-right">
                                 <img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/imagen_circulo.jpg" alt="Informacion Programa" style="width: 350px;height: 350px; border-radius: 95%;padding: 10px; border: 5px solid #0E8080;">
                              </div>
                           </div>
                           <!-- BRIEF HEADING -->
                           <div class="col-xs-10 col-xs-offset-1  col-md-offset-0 col-md-5 content-section brief-content-two">
                              <div class="brief-content-text text-justify" style="border-left: 1px solid #0E8080;">

                              	<ul style="text-decoration: none;list-style: none;">

                              		<li>
                              			<p><b>Nombre del Programa:</b> Biotecnología</p>
                              		</li>
                              		<li>
                              			<p><b>Duración:</b> (9) períodos académicos</p>
                              		</li>
                              		<li>
                              			<p><b>Sitio de ofrecimiento del programa:</b> Medellín</p>
                              		</li>
                              		<li>
                              			<p><b>Título que otorga:</b> Profesional en Biotecnología</p>
                              		</li>
                              		<li>
                              			<p><b>Metodología:</b> Presencial</p>
                              		</li>
                              		<li>
                              			<p><b>Registro Calificado:</b></br>
                              			Resolución No. 17170</br>
                              			de 27 de diciembre de 2012.</p>
                              		</li>
                              		<li>
                              			<p><b>Requisitos de admisión:</b></br>
										Los exigidos por la Ley 30 de 1992,</br>
										las pruebas de Estado (Saber-pro),</br>
										Prueba de admisión Institucional	</p>	
                              		</li>                              		
                              	</ul>
														
                              </div>
                           </div>
                           <!-- .brief-content-one-->
                        </div>
                     </div>
                  </div>
                  <div class="">
                     <div class="container">
                        <div class="row">
                           <!-- BRIEF IMAGE -->
                           <div class="col-xs-10 col-xs-offset-1  col-md-offset-0 col-md-6 brief-content-one">
                           		<h2 class="text-center dark-text"><span style="border-bottom: 2px solid #0E8080;padding: 0 20px;">PERFIL DEL GRADUADO</span></h2>
                              <div class="brief-content-text text-justify" >
                              	<p>El profesional en Biotecnología está en capacidad de desempeñarse o
								adaptarse en forma eficiente a industrias que basan sus procesos en la
								utilización de ciencias biológicas:</p>


                              	<ul >

                              		<li>
                              			<p>Manipulación de procesos fermentativos y procesos enzimáticos</p>
                              		</li>
                              		<li>
                              			<p>Aumento de la eficiencia de procesos agrícolas y pecuarios mediante
											la implementación de técnicas de cultivo in vitro y microbiológicas</p>
                              		</li>
                              		<li>
                              			<p>Investigación y desarrollo de productos mejorados para el consumo
											humano y animal.</p>
                              		</li>

                              		<li>
                              			<p>Control de calidad y bioprocesos.</p>
                              		</li>
                              		<li>
                              			<p>Investigación y desarrollo de procesos para la obtención de sustancias
										de interés farmacológico y cosmético a partir de sistemas biológicos.</p>
                              		</li>
                              		<li>
                              			<p>Implementación de procesos biológicos para el tratamiento de
										residuos sólidos, depuración de aguas, biorremedación de suelos y aire.</p>
                              		</li>
                              		                         		
                              	</ul>
								
														
                              </div>
                           </div>
                           <!-- BRIEF HEADING -->
                           <div class="col-xs-10 col-xs-offset-1 col-md-5 col-md-offset-1 content-section brief-content-two">
                           		<h2 class="text-center dark-text"><span style="border-bottom: 2px solid #0E8080;padding: 0 20px;">PERFIL DEL GRADUADO</span></h2>
                              <div class="brief-content-text text-justify" >
                              	<img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/imagen_objeto-de-estudio.jpg" alt="Perfil graduado" >
                              	<p>El Biotecnologo es un Profesional que esta formado bajo
								criterios de excelencia, pertinencia académica y social,
								contribuyan con el crecimiento y desarrollo sostenible,
								permitiendo el fortalecimiento de las interacciones entre
								instituciones educativas y grupos de investigación con el
								sector productivo; convirtiéndose así en un factor de
								desarrollo científico, tecnológico, económico y social.</p>
                             						
                              </div>
                           </div>
                           <!-- .brief-content-one-->
                        </div>
                     </div>
                  </div>
               </section>
               <section class="call-to-action ribbon-wrap" id="ribbon" style="background-image:url(//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/imagen_cinco_razones.jpg) !important; " role="region" aria-label="Ribbon">
                  <div class="section-overlay-layer">
                     <div class="container-fluid">
                     	<div class="section-header">
                           <h2 style="color:white;">5 RAZONES PARA ESTUDIAR EN COLMAYOR</h2>
                        </div>
                        <div class="row">
                           <div class="col-md-12">
                             	<div class="col-xs-12  col-md-offset-0 col-md-4 razon-para-estudiar" >
	                              <div class="service-box" parallax_onegrid-attr="this-0">
	                                 <div class="border-bottom-hover">
	                                    <div class="service-icon colored-text">
	                                       <img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/icono2.png" alt="razón 1">
	                                    </div>
	                                    <div class="razones-numeros "> 
	                                    	<h3 class="colored-text">1</h3> 
	                                    	<p>Más de 70 años aportando desde la academia al sector productivo</p>
                                    	</div>
	                                    
	                                 </div>
	                              </div>
	                           </div>
	                           <div class="col-xs-12  col-md-offset-0 col-md-4 razon-para-estudiar">
	                              <div class="service-box" parallax_onegrid-attr="this-1">
	                                 <div class="border-bottom-hover">
	                                    <div class="service-icon colored-text">
	                                       <img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/icono3.png" alt="razón 1">
	                                    </div>
	                                    <div class="razones-numeros"> 
		                                    <h3 >2</h3>
		                                    <p>Hace parte de las IES de la<br/>Alcaldía de Medellín</p>
	                                    </div>
	                                 </div>
	                              </div>
	                           </div>
	                           <div class="col-xs-12  col-md-offset-0 col-md-4 razon-para-estudiar">
	                              <div class="service-box" parallax_onegrid-attr="this-2">
	                                 <div class="border-bottom-hover">
	                                    <div class="service-icon colored-text">
	                                       <img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/icono1.png" alt="razón 1">
	                                    </div>
	                                    <div class="razones-numeros"> 
		                                    <h3 >3</h3>
		                                    <p>Es miembro de la Organización Mundial de Turismo - OMT.</p>
	                                    </div>
	                                 </div>
	                              </div>
	                           </div>
                           </div>
                        </div>
                        <div class="row" >
                           <div class="col-md-8 col-md-offset-2" style="margin-top: 25px;">
                             	<div class="col-xs-12  col-md-offset-0 col-md-6 razon-para-estudiar">
	                              <div class="service-box" parallax_onegrid-attr="this-2">
	                                 <div class="border-bottom-hover">
	                                    <div class="service-icon colored-text">
	                                       <img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/icono4.png" alt="razón 1">
	                                    </div>
	                                    <div class="razones-numeros"> 
		                                    <h3 >4</h3>
		                                    <p>Reconocida por sus proyectos sostenibles patentados a nivel nacional e internacional</p>
	                                    </div>
	                                 </div>
	                              </div>
	                           </div>
	                           <div class="col-xs-12  col-md-offset-0 col-md-6 razon-para-estudiar">
	                              <div class="service-box" parallax_onegrid-attr="this-2">
	                                 <div class="border-bottom-hover">
	                                    <div class="service-icon colored-text">
	                                       <img src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/biotecnologia/icono5.png" alt="razón 1">
	                                    </div>
	                                    <div class="razones-numeros"> 
		                                    <h3 >5</h3>
		                                    <p>Administración de convenios nacionales para el sector público y privado</p>
	                                    </div>
	                                 </div>
	                              </div>
	                           </div>	                           
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="services" id="services" role="region" aria-label="Services">
                  <div class="section-overlay-layer">
                     <div class="container">
                        <div class="section-header">
                           <h2 class="dark-text">TESTIMONIOS</h2>
                           <div class="colored-line"></div>
                           <div class="sub-heading"><p>Estudiar en la Institución Universitaria Colegio Mayor de Antioquia te abre las puertas a un mundo lleno de oportunidades, podrás creer en<br>
							tus sueños, conocer tu potencial y crecer como profesional. Dale un chance a tu proyecto de vida, estudia en Colmayor un programa con<br>
						pertinencia social y amplia posibilidad laboral.</p></div>
                        </div>
                        <div>
                        	
                        </div>
                     </div>
                  </div>
               </section>

               <!-- .brief-design-one -->
               <section class="team" id="team" role="region" aria-label="Team" style="background-color: #F5F5F5;">
                  <div class="section-overlay-layer">
                     <div class="container">
                        <div class="section-header">
                           <h2 class="dark-text">CRÉDITOS EDUCATIVOS Y BECAS</h2>
                           <div class="colored-line"></div>
                           <div class="sub-heading">Colmayor tiene convenios con entidades financieras, y además ofrece asesorías<br>
								para adquirir créditos para la matrícula y el sostenimiento:</div>
                        </div>
                        <div class="row">
                           <!-- BRIEF IMAGE -->
							
                           <div class="col-xs-10 col-xs-offset-1  col-md-offset-0 col-md-6 brief-content-one">
                              	<ul >
                              		<li>
                              			<p>Presupuesto Participativo- convenio directo con las comunas</p>
                              		</li>
                              		<li>
                              			<p>Presupuesto Participativo – Icetex</p>
                              		</li>
                              		<li>
                              			<p>Fondo Sapiencia</p>
                              		</li>

                              		<li>
                              			<p>Alianza AMA</p>
                              		</li>
                              		<li>
                              			<p>Fondo Comunidades Negras – Icetex</p>
                              		</li>
                              		<li>
                              			<p>Fondo Víctimas del Conflicto Armado - Icetex</p>
                              		</li> 
                              		<li>
                              			<p>Mejores Bachilleres</p>
                              		</li> 
                              		<li>
                              			<p>Estudiantioquia</p>
                              		</li> 
                              		<li>
                              			<p>Fondo Andres Bello</p>
                              		</li> 
                              		<li>
                              			<p>ICBF ASCUN</p>
                              		</li>                              		                         		
                              	</ul>
                           </div>
                           <!-- BRIEF HEADING -->
                           <div class="col-xs-10 col-xs-offset-1 col-md-5 col-md-offset-1 content-section brief-content-two">
                           		<ul >
                              		<li>
                              			<p>Becas Municipio de Itagüí</p>
                              		</li>
                              		<li>
                              			<p>Becas Municipio de Envigado</p>
                              		</li>
                              		<li>
                              			<p>Creditos Icetex – Mediano plazo y Acces</p>
                              		</li>

                              		<li>
                              			<p>Fondo Jóvenes en Acción</p>
                              		</li>
                              		<li>
                              			<p>Cooperativa Comuna</p>
                              		</li>
                              		<li>
                              			<p>Cooperativa Cooservunal</p>
                              		</li> 
                              		<li>
                              			<p>Serfinansa</p>
                              		</li> 
                              		<li>
                              			<p>Fincomercio</p>
                              		</li> 
                              		<li>
                              			<p>Banco Pichincha</p>
                              		</li>                              		                         		
                              	</ul>
                           </div>
                           <!-- .brief-content-one-->
                        </div>
                     </div>
                  </div>
                  <!-- container  -->
               </section>
               
               
              
               <div class="contact-info" id="contactinfo" role="region" aria-label="Contact Info">
                  <div class="section-overlay-layer">
                     <div class="container">
                        <div class="row contact-links">
                           <div class="col-sm-4 contact-link-box col-xs-12">
                              <div class="icon-container"><span class="fa icon-basic-mail colored-text"></span></div>
                              <a href="#" class="strong">contact@site.com</a>
                           </div>
                           <div class="col-sm-4 contact-link-box col-xs-12">
                              <div class="icon-container"><span class="fa icon-basic-geolocalize-01 colored-text"></span></div>
                              <a href="#" class="strong">Company address</a>
                           </div>
                           <div class="col-sm-4 contact-link-box col-xs-12">
                              <div class="icon-container"><span class="fa icon-basic-tablet colored-text"></span></div>
                              <a href="#" class="strong">0 332 548 954</a>
                           </div>
                        </div>
                        <!-- .contact-links -->
                     </div>
                     <!-- .container -->
                  </div>
               </div>
               <!-- .contact-info -->
            </div>
            <!-- .content-wrap -->
            <footer itemscope="" itemtype="http://schema.org/WPFooter" id="footer" role="contentinfo" class="footer grey-bg">
               <div class="container">
                  <div class="footer-widget-wrap">
                  </div>
                  <!-- .footer-widget-wrap -->
                  <div class="footer-bottom-wrap">
                     <span class="parallax_one_copyright_content">Themeisle</span>
                     <div itemscope="" role="navigation" itemtype="http://schema.org/SiteNavigationElement" id="menu-secondary" aria-label="Secondary Menu">
                        <h2 class="screen-reader-text">Secondary Menu</h2>
                     </div>
                     <ul class="social-icons">
                        <li>
                           <a target="_blank" href="#">
                           <span class="fa parallax-one-footer-icons icon-social-facebook transparent-text-dark"></span>
                           </a>
                        </li>
                        <li>
                           <a target="_blank" href="#">
                           <span class="fa parallax-one-footer-icons icon-social-twitter transparent-text-dark"></span>
                           </a>
                        </li>
                        <li>
                           <a target="_blank" href="#">
                           <span class="fa parallax-one-footer-icons icon-social-googleplus transparent-text-dark"></span>
                           </a>
                        </li>
                     </ul>
                  </div>
                  <!-- .footer-bottom-wrap -->
                  <div class="powered-by"><a href="https://themeisle.com/themes/parallax-one/" target="_blank" rel="nofollow">Parallax One </a>powered by <a class="" href="http://wordpress.org/" target="_blank" rel="nofollow">WordPress</a></div>
               </div>
               <!-- container -->
            </footer>
         </div>
      </div>
      <!-- Google Tag Manager (noscript) -->
      <noscript>&lt;iframe src="//www.googletagmanager.com/ns.html?id=GTM-WGDWZNL"
         height="0" width="0" style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;
      </noscript>
      <!-- End Google Tag Manager (noscript) --><script type="text/javascript" src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/js/bootstrap.min.js?ver=3.3.5"></script>
      <script type="text/javascript">
         /* <![CDATA[ */
         var screenReaderText = {"expand":"<span class=\"screen-reader-text\">expand child menu<\/span>","collapse":"<span class=\"screen-reader-text\">collapse child menu<\/span>"};
         /* ]]> */
      </script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/js/custom.all.js?ver=2.0.2"></script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/js/custom.home.js?ver=1.0.0"></script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-content/themes/Parallax-One/js/skip-link-focus-fix.js?ver=1.0.0"></script>
      <script type="text/javascript" src="//programas.colmayor.edu.co/wp-includes/js/wp-embed.min.js?ver=4.8.3"></script>
      <style type="text/css">.header{ background-image: url(//programas.colmayor.edu.co/wp-content/themes/Parallax-One/images/background-images/background.jpg);}.overlay-layer-wrap{ background:rgba(0, 0, 0, 0.7);}</style>
   </body>
</html>